#pragma once
#include "ISort.h"
#include "MergeSort.h"
#include <fstream>
#include <string>
class ExternalMergeSort :
	public ISort
{
public:
	ExternalMergeSort();
	~ExternalMergeSort();
	virtual void sortArray(int * array, int arraySize);
	void sortArray(std::string inputFile);
	virtual char * getName() { return "External Merge Sort"; }
private:
	MergeSort mergeSort;
	std::fstream originalFile;
	std::fstream inputFile1;
	std::fstream inputFile2;
	std::fstream mergeFile1;
	std::fstream mergeFile2;
	const std::string INPUT_1 = "external/input1.txt";
	const std::string INPUT_2 = "external/input2.txt";
	const std::string MERGE_1 = "external/merge1.txt";
	const std::string MERGE_2 = "external/merge2.txt";
	std::string doMergeSort(std::string inputFile);
	bool doMerge(int runSize, int length, bool flag);
};

