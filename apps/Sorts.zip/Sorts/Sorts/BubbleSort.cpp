#include "BubbleSort.h"



BubbleSort::BubbleSort()
{
}


BubbleSort::~BubbleSort()
{
}

void BubbleSort::sortArray(int * array, int arraySize)
{
	bool arrayInOrder = false;
	int sortIterations = 0;
	//continue to loop until the array is in order
	while (!arrayInOrder) {
		bool orderAffected = false;
		//move up the array an element at a time to compare and swap if needed
		//always pushes the largest number to the top of the array
		for (int i = 0; i < arraySize - sortIterations - 1; i++) {
			if (i != arraySize - 1) {
				int currentInt = array[i];
				int nextInt = array[i + 1];
				if (currentInt > nextInt) {
					array[i] = nextInt;
					array[i + 1] = currentInt;
					//flip this bool to let the loop know an element has changed
					orderAffected = true;
				}
			}
		}
		//used so that the loop doesn't check already sorted numbers
		sortIterations++;
		//break the loop if nothing changed
		arrayInOrder = !orderAffected;
	}
}
