#pragma once
#include "ISort.h"
class QuickSort :
	public ISort
{
public:
	QuickSort();
	~QuickSort();
	virtual void sortArray(int * array, int arraySize);
	virtual char * getName() { return "Quick Sort"; }
private:
	void quickSort(int * array, int start, int end, int arraySize);
	int partition(int * array, int start, int end);
};

