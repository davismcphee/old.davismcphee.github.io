#pragma once
#include "ISort.h"
class ShellSort :
	public ISort
{
public:
	ShellSort();
	~ShellSort();
	virtual void sortArray(int * array, int arraySize);
	virtual char * getName() { return "Shell Sort"; }
};

