#include "QuickSort.h"



QuickSort::QuickSort()
{
}


QuickSort::~QuickSort()
{
}

void QuickSort::sortArray(int * array, int arraySize)
{
	quickSort(array, 0, arraySize - 1, arraySize);
}

void QuickSort::quickSort(int * array, int start, int end, int arraySize)
{
	//if the start of this sort iteration is smaller than the end of it
	if (start < end) {
		//find the pivot
		int pivot = partition(array, start, end);
		//call recursively on both sides of the pivot
		quickSort(array, start, pivot - 1, arraySize);
		quickSort(array, pivot + 1, end, arraySize);
	}
}

int QuickSort::partition(int * array, int start, int end)
{
	//set the pivot at the start index of this partition
	int pivotIndex = start;
	int pivot = array[start];
	//loop through the partition
	for (int i = start; i <= end; i++) {
		//if the pivot is larger than this element,
		//put this element in the pivot spot,
		//replace this element's index with the element after the pivot
		//replace that element with the pivot
		if (pivot > array[i]) {
			array[pivotIndex] = array[i];
			array[i] = array[pivotIndex + 1];
			array[pivotIndex + 1] = pivot;
			pivotIndex++;
		}
	}
	return pivotIndex;
}
