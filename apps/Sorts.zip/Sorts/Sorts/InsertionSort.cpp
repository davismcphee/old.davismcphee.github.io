#include "InsertionSort.h"



InsertionSort::InsertionSort()
{
}


InsertionSort::~InsertionSort()
{
}

void InsertionSort::sortArray(int * array, int arraySize)
{
	bool arrayInOrder = false;
	int lastSortedIndex = 0;
	//continue to loop until the array is in order
	while (!arrayInOrder) {
		//the current int index is always one greater than what's been sorted
		int currentIntIndex = lastSortedIndex + 1;
		int currentInt = array[currentIntIndex];
		//move down the list beginning at the last sorted index
		for (int i = lastSortedIndex; i >= 0; i--) {
			//if the current int is less than this index's int
			//swap them with each other
			//always pulls the smallest number to the front
			if (currentInt < array[i]) {
				array[currentIntIndex] = array[i];
				array[i] = currentInt;
				currentIntIndex = i;
			}
			//else, that int is already sorted
			else {
				lastSortedIndex++;
				break;
			}
		}
		//break the loop when everything has been sorted
		arrayInOrder = (lastSortedIndex == arraySize - 1);
	}
}
