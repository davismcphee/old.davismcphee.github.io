#pragma once
#include "ISort.h"
#include <cmath>
#include <string>
class MergeSort :
	public ISort
{
public:
	MergeSort();
	~MergeSort();
	virtual void sortArray(int * array, int arraySize);
	virtual char * getName() { return "Merge Sort"; }
private:
	void doMergeSort(int * array, int pivot, int range);
	void doMerge(int * array, int pivot, int range);
};

