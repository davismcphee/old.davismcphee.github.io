#include "SelectionSort.h"



SelectionSort::SelectionSort()
{
}


SelectionSort::~SelectionSort()
{
}

void SelectionSort::sortArray(int * array, int arraySize)
{
	bool arrayInOrder = false;
	int sortIterations = 0;
	//continue to loop until the array is in order
	while (!arrayInOrder) {
		//this will always end the loop as the next smallest int in the list
		int smallestInt = array[sortIterations];
		//start checking elements beginning with the one after what's been sorted
		for (int i = sortIterations + 1; i < arraySize; i++) {
			//if this element is smaller than the one currently selected, swap them
			if (array[i] < smallestInt) {
				int newSmallestInt = array[i];
				array[i] = smallestInt;
				smallestInt = newSmallestInt;
				array[sortIterations] = smallestInt;
			}
		}
		//used so that the loop doesn't check already sorted numbers
		sortIterations++;
		//break the loop when everything has been sorted
		arrayInOrder = (sortIterations == arraySize - 1);
	}
}
