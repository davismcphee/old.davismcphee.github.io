#include "MergeSort.h"

MergeSort::MergeSort()
{
}

MergeSort::~MergeSort()
{
}

void MergeSort::sortArray(int * array, int arraySize)
{
	doMergeSort(array, 0, arraySize - 1);
}

//http://www.sourcetricks.com/2011/06/merge-sort.html#.WMiEY_nysdU
void MergeSort::doMergeSort(int * array, int pivot, int range)
{
	//if the pivot is greater than the range
	if (pivot < range) {
		int middle = floor((pivot + range) / 2);
		//call recursively on both halfs of this block
		doMergeSort(array, pivot, middle);
		doMergeSort(array, middle + 1, range);
		//merge the sorted halves of this block
		doMerge(array, pivot, range);
	}
}

void MergeSort::doMerge(int * array, int pivot, int range)
{
	int middle = floor((pivot + range) / 2);
	int temporaryArrayIndex = 0;
	int firstArrayIndex = pivot;
	int secondArrayIndex = middle + 1;

	//created a temporary array to store sorted values
	int * temporaryArray = new int[range - pivot + 1];

	//while both indexs are smaller than their halve of the block
	//put the smaller one if the temp array
	while (firstArrayIndex <= middle && secondArrayIndex <= range) {
		if (array[firstArrayIndex] < array[secondArrayIndex]) {
			temporaryArray[temporaryArrayIndex] = array[firstArrayIndex];
			firstArrayIndex++;
		}
		else {
			temporaryArray[temporaryArrayIndex] = array[secondArrayIndex];
			secondArrayIndex++;
		}
		temporaryArrayIndex++;
	}

	//put remaining numbers from the first halve in the temp array
	while (firstArrayIndex <= middle) {
		temporaryArray[temporaryArrayIndex] = array[firstArrayIndex];
		temporaryArrayIndex++;
		firstArrayIndex++;
	}

	//put remaining numbers from the second halve in the temp array
	while (secondArrayIndex <= range) {
		temporaryArray[temporaryArrayIndex] = array[secondArrayIndex];
		temporaryArrayIndex++;
		secondArrayIndex++;
	}

	//replace this block in the actual array with temp array values
	for (int i = pivot; i <= range; i++)
		array[i] = temporaryArray[i - pivot];

	delete[] temporaryArray;

}
