#pragma once
#include "ISort.h"
class SelectionSort :
	public ISort
{
public:
	SelectionSort();
	~SelectionSort();
	virtual void sortArray(int * array, int arraySize);
	virtual char * getName() { return "Selection Sort"; }
};

