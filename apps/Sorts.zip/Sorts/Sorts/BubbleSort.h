#pragma once
#include "ISort.h"
class BubbleSort :
	public ISort
{
public:
	BubbleSort();
	~BubbleSort();
	virtual void sortArray(int * array, int arraySize);
	virtual char * getName() { return "Bubble Sort"; }
};

