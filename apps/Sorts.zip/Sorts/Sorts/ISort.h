#pragma once
class ISort
{
public:
	virtual ~ISort() {}
	virtual void sortArray(int * array, int arraySize) = 0;
	virtual char * getName() = 0;
};

