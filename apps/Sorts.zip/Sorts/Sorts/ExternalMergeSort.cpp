#include "ExternalMergeSort.h"
#include <iostream>

ExternalMergeSort::ExternalMergeSort()
{
}

ExternalMergeSort::~ExternalMergeSort()
{
}

void ExternalMergeSort::sortArray(int * array, int arraySize)
{
	mergeSort.sortArray(array, arraySize);
}

void ExternalMergeSort::sortArray(std::string inputFile)
{
	//do the merge sort
	doMergeSort(inputFile);
	//write it to the output file
	std::fstream outputFile;
	outputFile.open(inputFile.substr(0, inputFile.find_last_of('.')) + "_sorted.txt", std::fstream::out);
	inputFile1.open(INPUT_1, std::fstream::in);
	int num;
	while (inputFile1 >> num)
		outputFile << num << ' ';
	outputFile.close();
	inputFile1.close();
}

std::string ExternalMergeSort::doMergeSort(std::string inputFile)
{
	originalFile.open(inputFile, std::fstream::in);
	inputFile1.open(INPUT_1, std::fstream::out);
	inputFile2.open(INPUT_2, std::fstream::out);

	bool flag = true;
	int num;
	int length = 0;
	bool even = false;
	int int1;
	int int2;

	//alternating between input files each run,
	//write runs of sorted numbers of size two
	//until the whole file has been read
	if (originalFile.is_open()) {
		while (originalFile >> int1) {
			length++;
			if (originalFile >> int2) {
				length++;
				if (int1 > int2)
					std::swap(int1, int2);
				if (even)
					inputFile1 << int1 << ' ' << int2 << ' ';
				else
					inputFile2 << int1 << ' ' << int2 << ' ';
			}
			else {
				if (even)
					inputFile1 << int1 << ' ';
				else
					inputFile2 << int2 << ' ';
			}
			even = !even;
		}
	}

	originalFile.close();
	inputFile1.close();
	inputFile2.close();

	int runSize = 2;
	flag = true;
	//do merges, doubling in size until the array is sorted
	while (!doMerge(runSize, length, flag)) {
		runSize *= 2;
		flag = !flag;
	}

	return INPUT_1;
}

bool ExternalMergeSort::doMerge(int runSize, int length, bool flag)
{
	std::string merge1Name;
	std::string merge2Name;

	//swap the input files with the merge files on each merge
	if (flag) {
		inputFile1.open(INPUT_1, std::fstream::in);
		inputFile2.open(INPUT_2, std::fstream::in);
		merge1Name = MERGE_1;
		merge2Name = MERGE_2;
	}
	else {
		inputFile1.open(MERGE_1, std::fstream::in);
		inputFile2.open(MERGE_2, std::fstream::in);
		merge1Name = INPUT_1;
		merge2Name = INPUT_2;
	}

	bool mergeComplete = false;
	int mergeCount = 0;
	bool originalMergeFile = true;
	int numBackup = -1;
	int num2Backup = -1;

	//loop until the current runs have been merged
	while (!mergeComplete) {

		std::ofstream activeMergeFile;
		std::string activeMergeFileName;

		//swap the merge file the current run will be written to
		if (originalMergeFile)
			activeMergeFileName = merge1Name;
		else
			activeMergeFileName = merge2Name;

		//open the merge file from a blank state if it is a new merge
		//open in append if it is not
		if (mergeCount < 2)
			activeMergeFile.open(activeMergeFileName);
		else
			activeMergeFile.open(activeMergeFileName, std::ios_base::app);

		//flip this bool to let the next loop know which merge file to use
		originalMergeFile = !originalMergeFile;

		int num;
		int num2;
		int list1Index = 0;
		int list2Index = 0;
		int inputFile1Pos;
		int inputFile2Pos;

		//while both list indexes are less than the current run size
		while (list1Index < runSize && list2Index < runSize) {
			//if there are backups of both numbers
			if (numBackup != -1 && num2Backup != -1) {
				//write the one which is smaller to the merge file and clear it
				if (numBackup < num2Backup) {
					activeMergeFile << numBackup << ' ';
					numBackup = -1;
					list1Index++;
				}
				else {
					activeMergeFile << num2Backup << ' ';
					num2Backup = -1;
					list2Index++;
				}
			}
			//if only the first number is backed up
			else if (numBackup != -1) {
				if (inputFile2 >> num2) {
					num2Backup = num2;
					if (numBackup < num2) {
						activeMergeFile << numBackup << ' ';
						numBackup = -1;
						list1Index++;
					}
					else {
						activeMergeFile << num2 << ' ';
						num2Backup = -1;
						list2Index++;
					}
				}
				else
					break;
			}
			//if only the second
			else if (num2Backup != -1) {
				if (inputFile1 >> num) {
					numBackup = num;
					if (num < num2Backup) {
						activeMergeFile << num << ' ';
						numBackup = -1;
						list1Index++;
					}
					else {
						activeMergeFile << num2Backup << ' ';
						num2Backup = -1;
						list2Index++;
					}
				}
				else
					break;
			}
			//if neither numbers are backed up, write both of them to variables
			else if (inputFile1 >> num && inputFile2 >> num2) {
				//write the smaller one to the merge file and back the other up
				if (num < num2) {
					activeMergeFile << num << ' ';
					num2Backup = num2;
					list1Index++;
				}
				else {
					activeMergeFile << num2 << ' ';
					numBackup = num;
					list2Index++;
				}
			}
			else
				break;
		}

		//write the remaining first number backup to the merge if there is one
		if (list1Index < runSize && numBackup != -1) {
			activeMergeFile << numBackup << ' ';
			numBackup = -1;
			list1Index++;
		}

		//write the remaining second number backup to the merge if there is one
		if (list2Index < runSize && num2Backup != -1) {
			activeMergeFile << num2Backup << ' ';
			num2Backup = -1;
			list2Index++;
		}

		//write the remaining first input numbers until the run is filled or numbers run out
		while (list1Index < runSize && inputFile1 >> num) {
			activeMergeFile << num << ' ';
			list1Index++;
		}

		//write the remaining second input numbers until the run is filled or numbers run out
		while (list2Index < runSize && inputFile2 >> num) {
			activeMergeFile << num << ' ';
			list2Index++;
		}

		//this bool checks if there are runs remaining to be merged
		int moreNums = false;

		if (inputFile1 >> num) {
			numBackup = num;
			moreNums = true;
		}

		if (inputFile2 >> num2) {
			num2Backup = num2;
			moreNums = true;
		}

		//if there are no more runs, the merge is complete
		if (!moreNums)
			mergeComplete = true;

		mergeFile1.close();
		mergeFile2.close();
		mergeCount++;

	}

	inputFile1.close();
	inputFile2.close();
	
	//if the run size was greater than half the length of the total list,
	//the list is completely sorted
	if (runSize >= (length / 2))
		return true;
	else
		return false;

}
