#include "ShellSort.h"



ShellSort::ShellSort()
{
}


ShellSort::~ShellSort()
{
}

//http://www.sanfoundry.com/cplusplus-program-implement-shell-sort/
void ShellSort::sortArray(int * array, int arraySize)
{
	int j;
	//cut the array in halves/steps each iteration until it can't be reduced more
	for (int step = arraySize / 2; step > 0; step /= 2) {
		//loop through the array beginning with this step
		for (int i = step; i < arraySize; i++) {
			int currentInt = array[i];
			//looping backward a step at a time from the current int index
			//as long as the current int is smaller than the one a step back from the current j index, swap them
			for (j = i; j >= step && currentInt < array[j - step]; j -= step)
				array[j] = array[j - step];
			array[j] = currentInt;
		}
	}
}
