#pragma once
#include "ISort.h"
class InsertionSort :
	public ISort
{
public:
	InsertionSort();
	~InsertionSort();
	virtual void sortArray(int * array, int arraySize);
	virtual char * getName() { return "Insertion Sort"; }
};

