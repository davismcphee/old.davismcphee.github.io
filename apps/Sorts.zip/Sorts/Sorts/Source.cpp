#include <iostream>
#include <string>
#include "../RandomArrayGenerator/RandomArrayGenerator.h"
#include "BubbleSort.h"
#include "SelectionSort.h"
#include "InsertionSort.h"
#include "ShellSort.h"
#include "MergeSort.h"
#include "QuickSort.h"
#include "ExternalMergeSort.h"
#include <regex>
#include <conio.h>
#include <chrono>

void copyArray(int * originalArray, int * targetArray, int arraySize) {
	for (int i = 0; i < arraySize; i++)
		targetArray[i] = originalArray[i];
}

int main() {

	ISort * sortingAlgorithms[] = { new BubbleSort(), new SelectionSort(), new InsertionSort(), new ShellSort(), new MergeSort(), new QuickSort() };
	std::string arraySizeString = "";

	//get a valid input for array sizes to test algorithms on
	while (!std::regex_match(arraySizeString, std::regex("[0-9]+")) && !std::regex_match(arraySizeString, std::regex("[0-9]+W"))) {
		std::cout << "Please enter a valid array size (append 'W' to enable write mode): ";
		std::cin >> arraySizeString;
	}

	int arraySize;
	bool writeMode = false;

	//enable write mode if the array size was tagged with a 'W'
	if (std::regex_match(arraySizeString, std::regex("[0-9]+W"))) {
		arraySize = std::stoi(arraySizeString.substr(0, arraySizeString.find('W')));
		writeMode = true;
	}
	else
		arraySize = std::stoi(arraySizeString);

	//set up the array generator and generate the array
	RandomArrayGenerator randomArrayGenerator;
	int * originalArray = randomArrayGenerator.generateArray(arraySize, 0, 32767);
	int * modifiableArray = new int[arraySize];

	//for each algorithm, copy the original array, and time and sort the copied array
	int sortingAlgorithmArraySize = sizeof(sortingAlgorithms) / sizeof(sortingAlgorithms[0]);
	for (int i = 0; i < sortingAlgorithmArraySize; i++) {
		copyArray(originalArray, modifiableArray, arraySize);
		auto startTime = std::chrono::high_resolution_clock::now();
		sortingAlgorithms[i]->sortArray(modifiableArray, arraySize);
		auto endTime = std::chrono::high_resolution_clock::now();
		//ask for the file name if write mode is enabled
		if (writeMode) {
			std::string fileName;
			std::cout << "Please enter a file name to write to for " << sortingAlgorithms[i]->getName() << ": ";
			std::cin >> fileName;
			randomArrayGenerator.writeArray(modifiableArray, arraySize, ',', fileName);
		}
		//output the time the algorithm took in milliseconds
		auto totalTime = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime).count();
		std::cout << "Algorithm: " << sortingAlgorithms[i]->getName() << "\nSpeed: " << totalTime << " milliseconds\n";
		std::cout << "--------------------------------------------------\n";
		//delete the current algorithm instance
		delete sortingAlgorithms[i];
	}

	//delete the arrays
	delete[] originalArray;
	delete[] modifiableArray;

	//ask if the external merge sort should be performed
	std::string mergeSortResponse;
	while (!std::regex_match(mergeSortResponse, std::regex("[YyNn]"))) {
		std::cout << "Perform external merge sort?(Y/N): ";
		std::cin >> mergeSortResponse;
	}

	//do and time the external merge sort if specified
	if (mergeSortResponse == "Y" || mergeSortResponse == "y") {
		std::string inputFile = "external/externalMergeSortArray.txt";
		ExternalMergeSort externalMergeSort;
		std::cout << "Performing external merge sort...\n";
		auto startTime = std::chrono::high_resolution_clock::now();
		externalMergeSort.sortArray(inputFile);
		auto endTime = std::chrono::high_resolution_clock::now();
		auto totalTime = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime).count();
		std::cout << "Speed: " << totalTime << " milliseconds\n";
	}

	std::cout << "Press any key to close...";
	_getch();

	return 0;

}