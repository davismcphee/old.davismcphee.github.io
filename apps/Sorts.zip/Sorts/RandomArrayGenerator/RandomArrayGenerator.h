#pragma once
#include <string>
//#include <cstdlib>
//#include <time.h>
#include <random>
#include <fstream>
class RandomArrayGenerator
{
public:
	RandomArrayGenerator();
	~RandomArrayGenerator();
	int * generateArray(int size, int rangeMin, int rangeMax);
	void writeArray(int * array, int arraySize, char delimiter, std::string outputFile);
	int getArraySizeFromFile(std::string arrayFile, char delimiter);
	int * generateArrayFromFile(std::string arrayFile, int arraySize, char delimiter);
	int * generateArrayFromFile(std::string arrayFile, int firstIndex, int lastIndex, char delimiter);
};

