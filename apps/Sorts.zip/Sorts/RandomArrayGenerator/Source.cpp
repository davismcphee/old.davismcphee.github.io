#include <string>
#include "RandomArrayGenerator.h"

int main() {
	int arraySize = 100000;
	RandomArrayGenerator randomArrayGenerator;
	int * generatedArray = randomArrayGenerator.generateArray(arraySize, 0, 1000000);
	randomArrayGenerator.writeArray(generatedArray, arraySize, ':', "test.txt");
	return 0;
}