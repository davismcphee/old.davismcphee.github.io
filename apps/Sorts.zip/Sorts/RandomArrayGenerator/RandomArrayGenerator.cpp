#include "RandomArrayGenerator.h"

RandomArrayGenerator::RandomArrayGenerator()
{
	/*srand(time(NULL));*/
}

RandomArrayGenerator::~RandomArrayGenerator()
{
}

//http://stackoverflow.com/questions/7560114/random-number-c-in-some-range
int * RandomArrayGenerator::generateArray(int size, int rangeMin, int rangeMax)
{
	/*int * newArray = new int[size];
	for (int i = 0; i < size; i++)
		newArray[i] = rangeMin + (rand() % (rangeMax - rangeMin + 1));
	return newArray;*/
	std::random_device randomDevice;
	std::mt19937 engine(randomDevice());
	std::uniform_int_distribution<> distribution(rangeMin, rangeMax);
	int * newArray = new int[size];
	for (int i = 0; i < size; i++)
		newArray[i] = distribution(engine);
	return newArray;
}

void RandomArrayGenerator::writeArray(int * array, int arraySize, char delimiter, std::string outputFile)
{
	std::ofstream outputStream;
	outputStream.open(outputFile);
	for (int i = 0; i < arraySize; i++) {
		outputStream << array[i];
		if (i != arraySize - 1)
			outputStream << delimiter;
	}
	outputStream.close();
}

int RandomArrayGenerator::getArraySizeFromFile(std::string arrayFile, char delimiter)
{
	std::ifstream inputStream;
	inputStream.open(arrayFile);
	int arraySize = 0;
	if (inputStream.is_open()) {
		arraySize = 1;
		char currenChar;
		while (inputStream.get(currenChar)) {
			if (currenChar == delimiter)
				arraySize++;
		}
	}
	return arraySize;
}

int * RandomArrayGenerator::generateArrayFromFile(std::string arrayFile, int arraySize, char delimiter) {
	std::ifstream inputStream;
	int * array = 0;
	inputStream.open(arrayFile);
	if (inputStream.is_open()) {
		array = new int[arraySize];
		int currentIndex = 0;
		std::string currentIntString;
		while (std::getline(inputStream, currentIntString, delimiter)) {
			array[currentIndex] = std::stoi(currentIntString);
			currentIndex++;
		}
		inputStream.close();
	}
	return array;
}


int * RandomArrayGenerator::generateArrayFromFile(std::string arrayFile, int firstIndex, int lastIndex, char delimiter) {
	std::ifstream inputStream;
	int * array = 0;
	inputStream.open(arrayFile);
	if (inputStream.is_open()) {
		array = new int[lastIndex - firstIndex];
		int fullArrayIndex = 0;
		int subArrayIndex = 0;
		std::string currentIntString;
		while (std::getline(inputStream, currentIntString, delimiter)) {
			if (fullArrayIndex >= firstIndex) {
				array[subArrayIndex] = std::stoi(currentIntString);
				subArrayIndex++;
			}
			fullArrayIndex++;
		}
		inputStream.close();
	}
	return array;
}

