$(function() {
              
    var postForm = $('#post_form');
    var postID = $("#post_id");
    var postTitle = $("#post_title");
    var postBody = $("#post_body");
    var postButton = $("#post_button");
    var clearButton = $("#clear_button");
    var postTableDiv = $(".post_table_div");
    var postTable = $("#post_table");
    var postTableTitles = $("#post_table_titles");
    var postTableBodies = $("#post_table_bodies");
    var postTableDates = $("#post_table_dates");
    var postTableActions = $("#post_table_actions");
    var postTableEditButtonClass = ".table_edit_button";
    var postTableDeleteButtonClass = ".table_delete_button";
    var spinner = $(".spinner");
    var posts;
    function Post(title, body, date) {
        this.title = title;
        this.body = body;
        this.date = date;
    }

    function showSpinner(flag) {
        if (flag)
            spinner.fadeIn();
        else
            spinner.fadeOut();
    }

    //http://stackoverflow.com/questions/4879367/how-to-create-jquery-dialog-in-function
    function createDialog(title, text, options) {
        return $("<div class='dialog' title='" + title + "'><p>" + text + "</p></div>").dialog(options);
    }

    function createPostTableRow(id, title, body, date) {
        var postTemplate = [`<tr data-id="${id}">`,
                            `   <td class="title">${title}</td>`,
                            `   <td class="body">${body}</td>`,
                            `   <td class="data">${date}</td>`,
                            `   <td class="table_buttons">`,
                            `       <i class="material-icons table_edit_button">mode_edit</i>`,
                            `       <i class="material-icons table_delete_button">delete</i>`,
                            `   </td>`,
                            `</tr>`].join("\n");
        return postTemplate;
    }

    function updatePostTable(e) {
        $.getJSON("http://localhost:3000/posts", function(data) {
            posts = data;
            postTableDiv.slideUp();
            postTable.children("tbody").html("");
            $.each(posts, function(i, post) {
                var postTableRow = createPostTableRow(post.id, post.title, post.body, post.date);
                postTable.children("tbody").append(postTableRow);
            });
            postTable.tablesorter();
            showSpinner(false);
            postTableDiv.slideDown();
        });            
    }

    //http://stackoverflow.com/questions/3552461/how-to-format-a-javascript-date
    function formatDate(date) {
        var monthNames = [
        "January", "February", "March",
        "April", "May", "June", "July",
        "August", "September", "October",
        "November", "December"
        ];
        var day = date.getDate();
        var monthIndex = date.getMonth();
        var year = date.getFullYear();
        return day + ' ' + monthNames[monthIndex] + ' ' + year;
    }

    function createPost(title, body) {
        var date = formatDate(new Date());
        var post = new Post(title, body, date);
        $.post("http://localhost:3000/posts", post, function() {
            updatePostTable();
        }, "json").fail(function(data) {
            createDialog("Error", data.statusText, null);
            showSpinner(false);
        });
    }

    function updatePost(id, title, body) {
        var date = formatDate(new Date());
        var post = new Post(title, body, date);
        $.ajax({
            url: `http://localhost:3000/posts/${id}`,
            data: post,
            type: 'put',
            dataType: 'json'
        }).done(function() {
            updatePostTable();
        }).fail(function(data) {
            createDialog("Error", data.statusText, null);
            showSpinner(false);
        });
    }

    function deletePost(id) {
        $.ajax({
            url: `http://localhost:3000/posts/${id}`,
            type: 'delete',
            dataType: 'json'
        }).done(function() {
            updatePostTable();
            showSpinner(false);
        }).fail(function(data) {
            createDialog("Error", data.statusText, null);
            showSpinner(false);
        });
    }

    function clearForm() {
        postID.data("id", "");
        postTitle.val("");
        postBody.val("");
        Materialize.updateTextFields();
    }

    postButton.click(function(e) {
        e.preventDefault();
        var id = postID.data("id");
        var title = postTitle.val();
        var body = postBody.val();
        if (title != "" && body != "") {
            if (id != "" && id != null) {
                createDialog("Overwrite Changes", "Are you sure you want to overwrite this post?", {
                    buttons: {
                        "Overwrite": function() {
                            showSpinner(true);
                            updatePost(id, title, body);
                            $(this).dialog("close");
                        },
                        Cancel: function() {
                            $(this).dialog("close");
                        }
                    }
                });
            }
            else {
                createPost(title, body);
                clearForm();
            }
        }
        else {
            createDialog("Invalid Input", "Oops! Your post requires both a title and body.", null);
        }
    });

    clearButton.click(function(e) {
        e.preventDefault();
        clearForm();
    });

    $(document).on("click", postTableEditButtonClass, function() {
        var thisRow = $(this).closest("tr");
        var id = thisRow.data("id");
        var title = thisRow.find(".title").html();
        var body = thisRow.find(".body").html();
        postID.data("id", id);
        postTitle.val(title);
        postBody.val(body);
        Materialize.updateTextFields();
    });

    $(document).on("click", postTableDeleteButtonClass, function() {
        var deleteButton = this;
        createDialog("Delete Note", "Are you sure you want to delete this note?", {
            buttons: {
                "Delete": function() {
                    var thisRow = $(deleteButton).closest("tr");
                    var id = thisRow.data("id");
                    showSpinner(true);
                    deletePost(id);
                    if (id == postID.data("id"))
                        clearForm();
                    $(this).dialog("close");
                },
                Cancel: function() {
                    $(this).dialog("close");
                }
            }
        });
    });

    showSpinner(true);
    updatePostTable();

});