﻿using System;
using System.Drawing;

namespace BallCatcherGame.Objects
{

    class Ball
    {
        private readonly double gravity = 0.98;
        private int minSize = 27;
        private int maxSize = 32;
        public int Size { get; set; }
        private int minSpeed = 5;
        private int maxSpeed = 10;
        private double speed;
        private Random random;
        private Image image;
        private Rectangle _BallDiplayArea = new Rectangle();
        public Rectangle BallDisplayArea
        {
            get
            {
                return _BallDiplayArea;
            }
        }
        private Rectangle gameDisplayArea;
        public enum BallType
        {
            Normal,
            Harmful,
            ExtraPoints,
            ExtraLife
        }
        public BallType Type { get; }
        public int Points
        {
            get
            {
                if (Type == BallType.ExtraPoints)
                    return Size;
                else if (Type == BallType.Harmful)
                    return -Size;
                else
                    return Size - 20;
            }
        }

        public Ball(Rectangle gameDisplayArea, Random random)
        {
            this.random = random;
            this.gameDisplayArea = gameDisplayArea;
            //randomize the size, speed and type of the ball
            Size = random.Next(minSize, maxSize);
            speed = random.Next(minSpeed, maxSpeed);
            Type = GetBallType(random.Next(100) + 1);
            //get the image based on the type
            GetImage();
            _BallDiplayArea.Height = Size;
            _BallDiplayArea.Width = Size;
            //randomly select the ball's x coordinate
            _BallDiplayArea.X = random.Next(gameDisplayArea.X, gameDisplayArea.Right - _BallDiplayArea.Width);
            _BallDiplayArea.Y = gameDisplayArea.Y - _BallDiplayArea.Height;
        }

        public Ball(Rectangle gameDisplayArea, int size, int speed, Image image)
        {
            this.Size = size;
            this.speed = speed;
            this.image = image;
        }

        public void Move()
        {
            _BallDiplayArea.Y += (int) speed;
            speed += gravity * gravity;
        }

        //http://stackoverflow.com/questions/5172906/c-rotating-graphics
        private Image RotateImage(Image image, float angle)
        {
            Image rotatedImage = new Bitmap(image.Width, image.Height);
            using (Graphics g = Graphics.FromImage(rotatedImage))
            {
                g.TranslateTransform(image.Width / 2, image.Height / 2); //set the rotation point as the center into the matrix
                g.RotateTransform(angle); //rotate
                g.TranslateTransform(-image.Width / 2, -image.Height / 2); //restore rotation point into the matrix
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
                g.DrawImage(image, new Point(0, 0)); //draw the image on the new bitmap
            }
            return rotatedImage;
        }

        public void Draw(Graphics graphics)
        {
            image = RotateImage(image, 90f);
            graphics.DrawImage(image, BallDisplayArea);
        }

        public bool IsInFrame()
        {
            return _BallDiplayArea.Y < (gameDisplayArea.Y + gameDisplayArea.Height - _BallDiplayArea.Height);
        }

        //determine which image this ball should use based on its type
        private void GetImage()
        {
            if (Type == BallType.Normal)
                image = Image.FromFile(Engine.Game.PATH + "..\\..\\Graphics\\normal.png");
            else if (Type == BallType.Harmful)
                image = Image.FromFile(Engine.Game.PATH + "..\\..\\Graphics\\harmful.png");
            else if (Type == BallType.ExtraPoints)
                image = Image.FromFile(Engine.Game.PATH + "..\\..\\Graphics\\extra_points.png");
            else
                image = Image.FromFile(Engine.Game.PATH + "..\\..\\Graphics\\extra_life.png");
        }

        //determine which type the ball will be
        private BallType GetBallType(int randomNumber)
        {
            if (randomNumber > 98)
                return BallType.ExtraLife;
            else if (randomNumber > 80)
                return BallType.ExtraPoints;
            else if (randomNumber > 30)
                return BallType.Normal;
            else
                return BallType.Harmful;
        }

    }
}
