﻿using BallCatcherGame.Engine;
using System;
using System.Drawing;

namespace BallCatcherGame.Objects
{
    class Player
    {
        public int Width { get; } = 150;
        public int Height { get; } = 150;
        private Rectangle _PlayerDiplayArea = new Rectangle();
        public Rectangle PlayerDisplayArea
        {
            get
            {
                return _PlayerDiplayArea;
            }
        }
        private Rectangle gameDisplayArea;
        private Game game;
        public int CollisionBoxTop { get; }
        public int CollisionBoxBottom { get; }
        private Image image = Image.FromFile(Game.PATH + "..\\..\\Graphics\\player.png");
        private Image imageLeft = Image.FromFile(Game.PATH + "..\\..\\Graphics\\player_left.png");
        private Image imageRight = Image.FromFile(Game.PATH + "..\\..\\Graphics\\player_right.png");
        private int lastX;
        private enum WalkState
        {
            None,
            Left,
            Right
        }
        private WalkState walkState;
        private int walkStateChangeInterval = 5;
        private int currentWalkStateInterval;
        Random random = new Random();

        public Player(Game game, Rectangle gameDisplayArea)
        {
            this.game = game;
            this.gameDisplayArea = gameDisplayArea;
            //set display area and place the player in the center of the screen
            _PlayerDiplayArea.Width = Width;
            _PlayerDiplayArea.Height = Height;
            _PlayerDiplayArea.X = (gameDisplayArea.Width / 2) - (Width / 2);
            _PlayerDiplayArea.Y = gameDisplayArea.Bottom - Height;
            //set the y coordinate where the collision box should begin and end
            CollisionBoxTop = _PlayerDiplayArea.Bottom - 85;
            CollisionBoxBottom = CollisionBoxTop + 50;
            walkState = WalkState.None;
        }

        public void Move()
        {
            //the player should move to the cursor position
            _PlayerDiplayArea.X = game.MouseX - (_PlayerDiplayArea.Width / 2);
            //if the mouse was moved
            if (lastX != _PlayerDiplayArea.X)
            {
                currentWalkStateInterval++;
                //if the interval between animation frames has passed
                if (currentWalkStateInterval > walkStateChangeInterval)
                {
                    //if the player was not moving before, randomize the walk state
                    if (walkState == WalkState.None)
                        walkState = (WalkState) random.Next(2) + 1;
                    //else, grab the opposite state of the one just active
                    else
                        walkState = walkState == WalkState.Left ? walkState = WalkState.Right : walkState = WalkState.Left;
                    currentWalkStateInterval = 0;
                }
            }
            //if mouse not moved, the player does not walk
            else
            {
                walkState = WalkState.None;
            }
            //take note of the last x value
            lastX = _PlayerDiplayArea.X;
            //lock the player with the game display area
            if (_PlayerDiplayArea.Right > gameDisplayArea.Right)
            {
                _PlayerDiplayArea.X = gameDisplayArea.Right - _PlayerDiplayArea.Width;
            }
            else if (_PlayerDiplayArea.X < gameDisplayArea.Left)
            {
                _PlayerDiplayArea.X = gameDisplayArea.Left;
            }
        }

        public void Draw(Graphics graphics)
        {
            //select the sprite to be used based on which part of the animation is playing
            if (walkState == WalkState.None)
                graphics.DrawImage(image, _PlayerDiplayArea);
            else if (walkState == WalkState.Left)
                graphics.DrawImage(imageLeft, _PlayerDiplayArea);
            else
                graphics.DrawImage(imageRight, _PlayerDiplayArea);
        }

    }
}
