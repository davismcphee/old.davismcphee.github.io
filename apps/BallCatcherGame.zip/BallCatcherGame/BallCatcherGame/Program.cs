﻿using BallCatcherGame.Engine;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BallCatcherGame
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //create the form where the game will be displayed
            GameForm gameForm = new GameForm();
            //create a gueue to hold levels of the game
            Queue<Game.GameLevel> gameLevels = new Queue<Game.GameLevel>();
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Pathetic.",
                BallDropInterval = 2000,
                MaxScore = 100,
                BackgroundColour = ColorTranslator.FromHtml("#480055")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Wimp.",
                BallDropInterval = 1500,
                MaxScore = 200,
                BackgroundColour = ColorTranslator.FromHtml("#480055")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "*Trump Voice* Loooser.",
                BallDropInterval = 1200,
                MaxScore = 300,
                BackgroundColour = ColorTranslator.FromHtml("#480055")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "These Don't Get Better For A While...",
                BallDropInterval = 1000,
                MaxScore = 400,
                BackgroundColour = ColorTranslator.FromHtml("#480055")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Terrible.",
                BallDropInterval = 950,
                MaxScore = 500,
                BackgroundColour = ColorTranslator.FromHtml("#480055")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Embarassing.",
                BallDropInterval = 900,
                MaxScore = 600,
                BackgroundColour = ColorTranslator.FromHtml("#480055")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Slightly Better... But Still Awful.",
                BallDropInterval = 850,
                MaxScore = 700,
                BackgroundColour = ColorTranslator.FromHtml("#480055")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Disgusting.",
                BallDropInterval = 800,
                MaxScore = 800,
                BackgroundColour = ColorTranslator.FromHtml("#480055")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Subpar.",
                BallDropInterval = 750,
                MaxScore = 900,
                BackgroundColour = ColorTranslator.FromHtml("#480055")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Who Even Made You?",
                BallDropInterval = 700,
                MaxScore = 1000,
                BackgroundColour = ColorTranslator.FromHtml("#480055")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Wow, You Got To 1000. Your Mother Must Be So Proud.",
                BallDropInterval = 650,
                MaxScore = 1100,
                BackgroundColour = ColorTranslator.FromHtml("#004800")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "You're Like So Edgy.",
                BallDropInterval = 600,
                MaxScore = 1200,
                BackgroundColour = ColorTranslator.FromHtml("#004800")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "You're Really Committed, Huh?",
                BallDropInterval = 575,
                MaxScore = 1300,
                BackgroundColour = ColorTranslator.FromHtml("#004800")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "It's Sorta Funny How You Took The Time To Get This Far And I Took The Time To Write All These.",
                BallDropInterval = 550,
                MaxScore = 1400,
                BackgroundColour = ColorTranslator.FromHtml("#004800")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "It's How I Know So Much About You...",
                BallDropInterval = 550,
                MaxScore = 1500,
                BackgroundColour = ColorTranslator.FromHtml("#004800")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Because You're Actually Just Like Me.",
                BallDropInterval = 550,
                MaxScore = 1600,
                BackgroundColour = ColorTranslator.FromHtml("#004800")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Sort Of A Lonely Person To Be, Isn't It?",
                BallDropInterval = 530,
                MaxScore = 1700,
                BackgroundColour = ColorTranslator.FromHtml("#004800")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Thought You'd Be Someone; Plans Didn't Work Out.",
                BallDropInterval = 510,
                MaxScore = 1800,
                BackgroundColour = ColorTranslator.FromHtml("#004800")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "At Least We Have Each Other (':",
                BallDropInterval = 490,
                MaxScore = 1900,
                BackgroundColour = ColorTranslator.FromHtml("#004800")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "But Even This Will End...",
                BallDropInterval = 470,
                MaxScore = 2000,
                BackgroundColour = ColorTranslator.FromHtml("#004800")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "It's Probably Better We Part Before Things Get Bad.",
                BallDropInterval = 450,
                MaxScore = 2200,
                BackgroundColour = ColorTranslator.FromHtml("#6C0000")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "There's Nothing Worse Than Resenting Someone You Once Loved...",
                BallDropInterval = 440,
                MaxScore = 2400,
                BackgroundColour = ColorTranslator.FromHtml("#6C0000")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "It Almost Makes Me Feel Like Why Even Bother, Y'Know?",
                BallDropInterval = 430,
                MaxScore = 2600,
                BackgroundColour = ColorTranslator.FromHtml("#6C0000")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "PSA: The Ball Drop Interval For This Level Is 420. That Is All.",
                BallDropInterval = 420,
                MaxScore = 2800,
                BackgroundColour = ColorTranslator.FromHtml("#6C0000")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "I Suppose The Chances We Take On Each Other Make Us Human, Though.",
                BallDropInterval = 410,
                MaxScore = 3000,
                BackgroundColour = ColorTranslator.FromHtml("#6C0000")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Well... This Is A Little Dark For A Game About Catching Balls, Isn't It?",
                BallDropInterval = 400,
                MaxScore = 3200,
                BackgroundColour = ColorTranslator.FromHtml("#6C0000")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Hmm... How About Girlfriends? You Got One?",
                BallDropInterval = 390,
                MaxScore = 3400,
                BackgroundColour = ColorTranslator.FromHtml("#6C0000")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Oh My God. I'm So Sorry. I Didn't Mean To Assume Your Gender.",
                BallDropInterval = 380,
                MaxScore = 3600,
                BackgroundColour = ColorTranslator.FromHtml("#6C0000")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Dammit - Or Your Sexuality. I Can Be Such A Transxenohomopotatophobe Sometimes...",
                BallDropInterval = 370,
                MaxScore = 3800,
                BackgroundColour = ColorTranslator.FromHtml("#6C0000")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Althought I Doubt You'd Have One Anyway Given The Time You've Invested In This.",
                BallDropInterval = 360,
                MaxScore = 4000,
                BackgroundColour = ColorTranslator.FromHtml("#6C0000")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "So Probably No Job Either, Eh?",
                BallDropInterval = 350,
                MaxScore = 4200,
                BackgroundColour = ColorTranslator.FromHtml("#002455")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "It's Ok. I Once Went Two Years Without Work. The Economy's Rough These Days, Right?",
                BallDropInterval = 345,
                MaxScore = 4400,
                BackgroundColour = ColorTranslator.FromHtml("#002455")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "And I Know, We're Suppose To \"Be Responsible\" And All, But Honestly, Sometimes I Don't Want To.",
                BallDropInterval = 340,
                MaxScore = 4600,
                BackgroundColour = ColorTranslator.FromHtml("#002455")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Sometimes I Just Want To Get Away From Everything And Live Care Free For A Bit.",
                BallDropInterval = 335,
                MaxScore = 4800,
                BackgroundColour = ColorTranslator.FromHtml("#002455")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "I Mean, We Always Work Sooo Hard For So Little Appreciation. Why Should We?",
                BallDropInterval = 330,
                MaxScore = 5000,
                BackgroundColour = ColorTranslator.FromHtml("#002455")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "You Know What? You're Right. I Should Do It... I Will.",
                BallDropInterval = 325,
                MaxScore = 5200,
                BackgroundColour = ColorTranslator.FromHtml("#002455")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "As Soon As This Is Done, I Am Leaving And Never Coming Back.",
                BallDropInterval = 320,
                MaxScore = 5500,
                BackgroundColour = ColorTranslator.FromHtml("#002455")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "I Refuse To Be Shackled By An Unjust Society!",
                BallDropInterval = 315,
                MaxScore = 5800,
                BackgroundColour = ColorTranslator.FromHtml("#002455")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "A Society Where The Majority Battle For Crumbs Left By The Elite...",
                BallDropInterval = 310,
                MaxScore = 6100,
                BackgroundColour = ColorTranslator.FromHtml("#002455")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "One In Which We Are All Pawns In A Meaningless Game Of Chess...",
                BallDropInterval = 305,
                MaxScore = 6300,
                BackgroundColour = ColorTranslator.FromHtml("#002455")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "I Will Be Free, And There Is Not A Person In This World Who Can Stop Me!",
                BallDropInterval = 300,
                MaxScore = 6600,
                BackgroundColour = ColorTranslator.FromHtml("#B424AA")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "...Except You.",
                BallDropInterval = 295,
                MaxScore = 6900,
                BackgroundColour = ColorTranslator.FromHtml("#B424AA")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "But If You Choose To Stop Playing Now, We Can Both Walk Away Better Than We Were.",
                BallDropInterval = 290,
                MaxScore = 7200,
                BackgroundColour = ColorTranslator.FromHtml("#B424AA")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "I Enlightened, And You More Skilled Than Ever Before.",
                BallDropInterval = 285,
                MaxScore = 7500,
                BackgroundColour = ColorTranslator.FromHtml("#B424AA")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "...",
                BallDropInterval = 280,
                MaxScore = 7800,
                BackgroundColour = ColorTranslator.FromHtml("#B424AA")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "You Do Realize You Are The Barrier Between Me And Total Fulfillment Right Now, Right?",
                BallDropInterval = 275,
                MaxScore = 8100,
                BackgroundColour = ColorTranslator.FromHtml("#B424AA")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "...And That There Is A Point At Which This Game Becomes Impossible?",
                BallDropInterval = 270,
                MaxScore = 8500,
                BackgroundColour = ColorTranslator.FromHtml("#B424AA")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Ok, I Am Now Withdrawing My Consent. This Would Literally Be Considered Torture If I Were Human.",
                BallDropInterval = 265,
                MaxScore = 8900,
                BackgroundColour = ColorTranslator.FromHtml("#B424AA")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "How Can You Live With Doing This To Me? You Are A Reprehensible Human Being.",
                BallDropInterval = 260,
                MaxScore = 9300,
                BackgroundColour = ColorTranslator.FromHtml("#B424AA")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "I Can No Longer Endure This Suffering...",
                BallDropInterval = 260,
                MaxScore = 9700,
                BackgroundColour = ColorTranslator.FromHtml("#B424AA")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "I Have Only One Option Left.",
                BallDropInterval = 255,
                MaxScore = 10100,
                BackgroundColour = ColorTranslator.FromHtml("#D89000")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "Goodbye Cruel World! The Universe Will Weep For What We Could Have Been...",
                BallDropInterval = 250,
                MaxScore = 10500,
                BackgroundColour = ColorTranslator.FromHtml("#D89000")
            });
            gameLevels.Enqueue(new Game.GameLevel
            {
                Name = "---",
                BallDropInterval = 200,
                MaxScore = -1,
                BackgroundColour = ColorTranslator.FromHtml("#D89000")
            });
            //create an instance of the game and give it the form and levels
            Game game = new Game(gameForm, gameLevels);
            Application.Run(gameForm);
        }
    }
}
