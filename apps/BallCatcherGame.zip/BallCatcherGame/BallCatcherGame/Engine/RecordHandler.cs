﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BallCatcherGame.Engine
{
    class RecordHandler
    {
        private Dictionary<int, int> _Records = new Dictionary<int, int>();
        public Dictionary<int, int> Records
        {
            get
            {
                return _Records;
            }
        }
        private string recordsFilePath;

        public RecordHandler(string recordsFilePath)
        {
            this.recordsFilePath = recordsFilePath;
            StreamReader streamReader = new StreamReader(this.recordsFilePath);
            string line;
            //read the lines of the record files, split by ':', parse as ints and place in dictionary
            while ((line = streamReader.ReadLine()) != null)
            {
                string[] lineParts = line.Split(':');
                int place = int.Parse(lineParts[0]);
                int score = int.Parse(lineParts[1]);
                _Records.Add(place, score);
            }
            streamReader.Close();
        }

        public void WriteRecords()
        {
            StreamWriter streamWriter = new StreamWriter(recordsFilePath);
            //write the updated records back to he records file
            foreach (KeyValuePair<int, int> record in _Records)
            {
                streamWriter.WriteLine(record.Key + ":" + record.Value);
            }
            streamWriter.Close();
        }

    }
}
