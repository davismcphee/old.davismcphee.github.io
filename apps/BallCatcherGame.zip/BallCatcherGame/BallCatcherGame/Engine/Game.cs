﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using BallCatcherGame.Objects;
using System.Drawing;
using System.Diagnostics;
using System.Drawing.Text;

namespace BallCatcherGame.Engine
{

    class Game
    {

        //determines the settings of a level
        public struct GameLevel
        {
            public int BallDropInterval { get; set; }
            public int MaxScore { get; set; }
            public string Name { get; set; }
            public Color BackgroundColour { get; set; }
        }

        //creates a temporary explosion
        private partial class Explosion
        {
            public Image Image { get; set; }
            public int Life { get; set; }
            public int Size { get; set; }
            public int Intervals { get; set; } = 0;
            public int X { get; set; }
            public int Y { get; set; }
        }

        //a shadow which attaches to a ball
        private partial class Shadow
        {
            public Image Image { get; } = Image.FromFile(Engine.Game.PATH + "..\\..\\Graphics\\ball_shadow.png");
            public int Width { get; set; } = 1;
            public int Height { get; set; } = 1;
            public int X;
            public int Y;
            public Ball ball;
            public Shadow(Ball ball, int y)
            {
                this.ball = ball;
                Y = y;
            }
        }

        private Form gameForm;
        private Timer gameTimer = new Timer();
        private int gameTimerTickSpeed = 17;
        private HashSet<Ball> balls = new HashSet<Ball>();
        private List<Explosion> explosions = new List<Explosion>();
        private Dictionary<Ball, Shadow> ballShadows = new Dictionary<Ball, Shadow>();
        private Player player;
        private int _MouseX;
        public int MouseX {
            get
            {
                return _MouseX;
            }
        }
        private int _MouseY;
        public int MouseY
        {
            get
            {
                return _MouseY;
            }
        }
        private int currentScore = 0;
        private int currentLives;
        private int currentLivesMin = 5;
        private Stopwatch ballDropStopwatch = new Stopwatch();
        private Random random = new Random();
        private Font headerFont;
        private Font labelFont;
        private Font bodyFont;
        Color headerColor = ColorTranslator.FromHtml("#FCFC00");
        private SolidBrush headerBrush;
        private SolidBrush bodyBrush = new SolidBrush(Color.White);
        private Point currentStatsPoint;
        private string currentLevelText;
        private string currentStatsText;
        private string infoText;
        Queue<GameLevel> gameLevelsBackup;
        Queue<GameLevel> gameLevels;
        GameLevel currentLevel;
        StringFormat centerText = new StringFormat();
        MciPlayer backgroundMusic = new MciPlayer(PATH + "..\\..\\Sounds\\music.mp3", "1");
        MciPlayer collect = new MciPlayer(PATH + "..\\..\\Sounds\\collect.mp3", "2");
        MciPlayer extraLife = new MciPlayer(PATH + "..\\..\\Sounds\\extra_life.mp3", "3");
        MciPlayer extraPoints = new MciPlayer(PATH + "..\\..\\Sounds\\extra_points.mp3", "4");
        MciPlayer hurt = new MciPlayer(PATH + "..\\..\\Sounds\\hurt.mp3", "5");
        MciPlayer gameOver = new MciPlayer(PATH + "..\\..\\Sounds\\game_over.mp3", "6");
        MciPlayer hurtMiss = new MciPlayer(PATH + "..\\..\\Sounds\\hurt_miss.mp3", "7");
        PrivateFontCollection privateFontCollection = new PrivateFontCollection();
        //static path to game root
        public static string PATH { get; } = AppDomain.CurrentDomain.BaseDirectory;
        RecordHandler recordHandler = new RecordHandler(PATH + "..\\..\\Data\\records.txt");
        bool gameInSession = false;
        bool newRecord = false;

        public Game(Form gameForm, Queue<GameLevel> gameLevels)
        {
            this.gameForm = gameForm;
            //backup the game levels for replay
            gameLevelsBackup = gameLevels;
            //add event handlers to the form
            gameForm.Paint += new PaintEventHandler(this.gameForm_Paint);
            gameForm.MouseMove += new MouseEventHandler(this.gameForm_MouseMove);
            gameForm.MouseClick += new MouseEventHandler(this.gameForm_MouseClick);
            gameForm.KeyDown += new KeyEventHandler(this.gameForm_KeyDown);
            //set the interval and tick for the game's timer
            gameTimer.Interval = gameTimerTickSpeed;
            gameTimer.Tick += Update;
            //create the player
            player = new Player(this, gameForm.DisplayRectangle);
            //do the necessary setup for the game's text and menu
            currentStatsPoint = new Point(gameForm.DisplayRectangle.Left + 10, 10);
            infoText = "Ready To Catch Some Balls?\n"
                + "Click To Start!\n\n"
                + "High Scores:\n"
                + "1st: " + recordHandler.Records[1] + "\n"
                + "2nd: " + recordHandler.Records[2] + "\n"
                + "3rd: " + recordHandler.Records[3];
            centerText.Alignment = StringAlignment.Center;
            centerText.LineAlignment = StringAlignment.Center;
            privateFontCollection.AddFontFile(PATH + "..\\..\\Fonts\\Fipps-Regular.otf");
            privateFontCollection.AddFontFile(PATH + "..\\..\\Fonts\\PressStart2P.ttf");
            privateFontCollection.AddFontFile(PATH + "..\\..\\Fonts\\munro_narrow.ttf");
            headerFont = new Font(privateFontCollection.Families[0], 12);
            labelFont = new Font(privateFontCollection.Families[2], 10);
            bodyFont = new Font(privateFontCollection.Families[1], 14, FontStyle.Bold);
            headerBrush = new SolidBrush(headerColor);
            //set the game's cursor to the custom one
            gameForm.Cursor = new Cursor(PATH + "..\\..\\Graphics\\crosshair.cur");
            //peek at the first level's background colour and apply it
            gameForm.BackColor = gameLevels.Peek().BackgroundColour;
        }

        private void gameForm_KeyDown(object sender, KeyEventArgs e)
        {
            //quit the game
            if (e.KeyCode == Keys.Escape)
            {
                Application.Exit();
            }
        }

        private void gameForm_MouseClick(object sender, MouseEventArgs e)
        {
            //start the game if one isn't in session
            if (!gameInSession)
                Start();
        }

        private void gameForm_MouseMove(object sender, MouseEventArgs e)
        {
            //grab the mouse coordinates relative to the game form
            _MouseX = e.X;
            _MouseY = e.Y;                
        }

        private void gameForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
        {
            //remove any smoothing mode
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
            //draw shadows for each ball
            foreach (Ball ball in balls)
            {
                Shadow shadow = ballShadows[ball];
                e.Graphics.DrawImage(shadow.Image, shadow.X, shadow.Y, shadow.Width, shadow.Height);
            }
            //draw the info/menu text
            e.Graphics.DrawString(
                infoText,
                headerFont,
                headerBrush,
                gameForm.DisplayRectangle.Left
                + (gameForm.DisplayRectangle.Width / 2),
                (gameForm.DisplayRectangle.Height / 2) - (headerFont.Height / 2),
                centerText);
            //draw the player
            player.Draw(e.Graphics);
            //show the current level's text, or no text if dead
            currentLevelText = currentLives > 0 ? currentLevel.Name : "";
            e.Graphics.DrawString(
                currentLevelText,
                bodyFont,
                bodyBrush,
                gameForm.DisplayRectangle.Left
                + (gameForm.DisplayRectangle.Width / 2),
                (gameForm.DisplayRectangle.Height / 2) - (headerFont.Height / 2),
                centerText);
            //draw each ball
            foreach (Ball ball in balls)
            {
                ball.Draw(e.Graphics);
            }
            //draw each explosion
            foreach (Explosion explosion in explosions)
            {
                e.Graphics.DrawImage(
                    explosion.Image,
                    explosion.X,
                    explosion.Y);
            }
            //set the current stats and draw them
            currentStatsText = $"Lives: {currentLives} | Current Score: {currentScore}";
            e.Graphics.DrawString(currentStatsText, labelFont, bodyBrush, currentStatsPoint);
        }

        public void Start()
        {
            //reset the game settings
            gameInSession = true;
            newRecord = false;
            backgroundMusic.PlayFromStart();
            backgroundMusic.PlayLoop();
            balls = new HashSet<Ball>();
            infoText = "";
            currentScore = 0;
            currentLives = currentLivesMin;
            //make a deep copy of the game levels backup
            gameLevels = new Queue<GameLevel>(gameLevelsBackup);
            //get the first level and start the game
            currentLevel = gameLevels.Dequeue();
            gameForm.BackColor = currentLevel.BackgroundColour;
            gameTimer.Start();
            ballDropStopwatch.Start();
        }

        public void Stop()
        {
            //stop the game session
            gameInSession = false;
            backgroundMusic.StopPlaying();
            //check for new record and choose display
            if (newRecord)
            {
                infoText = "New High Score!\n"
                    + "1st: " + recordHandler.Records[1] + "\n"
                    + "2nd: " + recordHandler.Records[2] + "\n"
                    + "3rd: " + recordHandler.Records[3] + "\n\n"
                    + "Click To Play Again!";
            }
            else
            {
                infoText = "You're Loser!\nClick To Catch Some More Balls!";
            }
            //stop the timers
            gameTimer.Stop();
            ballDropStopwatch.Reset();
    }

        public void Update(object sender, EventArgs e)
        {
            //if the player is not dead
            if (currentLives >= 1)
            {
                //check for levels, collisions, out of frame balls, explosions, and ball drops
                CheckForNextLevel();
                CheckForBallCollisions();
                balls.RemoveWhere(BallOutOfFrame);
                explosions.RemoveAll(ExplosionExpired);
                CheckForBallDrop();
                player.Move();
                //move each ball
                foreach (Ball ball in balls)
                {
                    ball.Move();
                    //set the shadow associated with this ball's position and size
                    Shadow shadow = ballShadows[ball];
                    //get the percent the ball has descended relative to the game display height
                    double percentDescended = (double)ball.BallDisplayArea.Bottom / (double) gameForm.DisplayRectangle.Bottom;
                    //calculate the shadow's dimensions and set them
                    int newWidth = (int) (percentDescended * ball.BallDisplayArea.Width);
                    if (newWidth < 1)
                        newWidth = 1;
                    shadow.Width = newWidth;
                    shadow.Height = newWidth / 2;
                    shadow.X = ball.BallDisplayArea.X + (ball.BallDisplayArea.Width / 2) - (shadow.Width / 2);
                }
                //increase the explosions' life intervals
                foreach (Explosion explosion in explosions)
                {
                    explosion.Intervals++;
                }
            }
            //if the player is dead
            else
            {
                gameOver.PlayFromStart();
                CheckForHighscore();
                Stop();
            }
            //proceed to paint the form
            gameForm.Invalidate();
        }

        private void CheckForHighscore()
        {
            //begin the player's place below the highscore table
            int place = 4;
            //for each record, check if the current score is greater than the record's score
            foreach (KeyValuePair<int, int> record in recordHandler.Records)
            {
                if (currentScore > record.Value)
                {
                    //check if the current place is lower on the high score table than this record
                    if (place > record.Key)
                    {
                        place = record.Key;
                    }
                }
            }
            //if the player made a high score
            if (place != 4)
            {
                recordHandler.Records[place] = currentScore;
                recordHandler.WriteRecords();
                newRecord = true;
            }
        }

        //determine if an explosion should be removed based on it's life intervals
        private bool ExplosionExpired(Explosion obj)
        {
            return obj.Intervals > obj.Life;
        }

        //get the next level if the current score is high enough and there is one
        private void CheckForNextLevel()
        {
            if (currentScore > currentLevel.MaxScore && currentLevel.MaxScore != -1)
            {
                currentLevel = gameLevels.Dequeue();
                gameForm.BackColor = currentLevel.BackgroundColour;
            }
        }

        //check if a ball should be dropped
        private void CheckForBallDrop()
        {
            if (ballDropStopwatch.ElapsedMilliseconds >= currentLevel.BallDropInterval)
            {
                ballDropStopwatch.Restart();
                Ball ball = new Ball(gameForm.DisplayRectangle, random);
                balls.Add(ball);
                ballShadows.Add(ball, new Shadow(ball, gameForm.DisplayRectangle.Height - 14));
            }
        }

        //remove balls which have collided with the player
        private void CheckForBallCollisions()
        {
            balls.RemoveWhere(BallCollision);
        }

        private bool BallCollision(Ball ball)
        {
            //if the ball collided with the player
            if (ball.BallDisplayArea.Bottom >= player.CollisionBoxTop
                && ball.BallDisplayArea.Bottom <= player.CollisionBoxBottom
                && ball.BallDisplayArea.Right >= player.PlayerDisplayArea.Left
                && ball.BallDisplayArea.Left <= player.PlayerDisplayArea.Right)
            {
                //if the ball is an extra life, give the player a life
                if (ball.Type == Ball.BallType.ExtraLife)
                {
                    currentLives++;
                    extraLife.PlayFromStart();
                }
                else
                {
                    //if the ball is harmul, take a life and spawn an explosion
                    if (ball.Type == Ball.BallType.Harmful)
                    {
                        currentLives--;
                        explosions.Add(new Explosion
                        {
                            Image = Image.FromFile(PATH + "..\\..\\Graphics\\explosion.png"),
                            Size = 42,
                            Life = 5,
                            X = ball.BallDisplayArea.X,
                            Y = ball.BallDisplayArea.Y
                        });
                        hurt.PlayFromStart();
                    }  
                    //if the ball gives extra points or is normal, just play the sound
                    else if (ball.Type == Ball.BallType.ExtraPoints)
                    {
                        extraPoints.PlayFromStart();
                    }
                    else
                    {
                        collect.PlayFromStart();
                    }
                    //update the score based on the ball's points
                    currentScore += ball.Points;
                }
                //lock the current score min to 0 and remove the active ball
                if (currentScore < 1)
                    currentScore = 0;
                ballShadows.Remove(ball);
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool BallOutOfFrame(Ball ball)
        {
            //if the ball was missed by the player
            if (!ball.IsInFrame())
            {
                //if the ball was not harmful, remove a life
                if (ball.Type != Ball.BallType.Harmful)
                {
                    currentLives -= 1;
                    hurtMiss.PlayFromStart();
                }
                //remove the ball shadow
                ballShadows.Remove(ball);
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
