﻿using LocalNote.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Text;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace LocalNote
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPageView : Page
    {

        MainPageViewModel viewModel;

        public MainPageView()
        {
            this.InitializeComponent();
            viewModel = (MainPageViewModel)this.DataContext;
            boldButton.IsEnabled = false;
            underlineButton.IsEnabled = false;
            italicButton.IsEnabled = false;
        }

        private void NoteList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            NoteContent.IsReadOnly = false;
            ITextDocument document = NoteContent.Document;
            if (viewModel.SelectedNote != null)
            {
                document.SetText(TextSetOptions.FormatRtf, viewModel.SelectedNote.Content);
                NoteContent.IsReadOnly = true;
                boldButton.IsEnabled = false;
                underlineButton.IsEnabled = false;
                italicButton.IsEnabled = false;
            }
            else
            {
                NoteContent.IsReadOnly = false;
                document = NoteContent.Document;
                document.SetText(TextSetOptions.FormatRtf, "");
                boldButton.IsEnabled = true;
                underlineButton.IsEnabled = true;
                italicButton.IsEnabled = true;
            }
        }

        private void NoteContent_TextChanged(object sender, RoutedEventArgs e)
        {
            ITextDocument document = NoteContent.Document;
            string documentContent;
            document.GetText(TextGetOptions.FormatRtf, out documentContent);
            viewModel.ActiveContent = documentContent;
        }

        private void AppBarButton_Click(object sender, RoutedEventArgs e)
        {
            NoteContent.IsReadOnly = false;
            boldButton.IsEnabled = true;
            underlineButton.IsEnabled = true;
            italicButton.IsEnabled = true;
        }

        private void AppBarButton_Click_1(object sender, RoutedEventArgs e)
        {
            NoteContent.IsReadOnly = true;
            boldButton.IsEnabled = false;
            underlineButton.IsEnabled = false;
            italicButton.IsEnabled = false;
        }

        private void AppBarButton_Click_3(object sender, RoutedEventArgs e)
        {
            Windows.UI.Text.ITextSelection selectedText = NoteContent.Document.Selection;
            if (selectedText != null)
            {
                Windows.UI.Text.ITextCharacterFormat charFormatting = selectedText.CharacterFormat;
                if (charFormatting.Underline == Windows.UI.Text.UnderlineType.None)
                {
                    charFormatting.Underline = Windows.UI.Text.UnderlineType.Single;
                }
                else
                {
                    charFormatting.Underline = Windows.UI.Text.UnderlineType.None;
                }
                selectedText.CharacterFormat = charFormatting;
            }
        }

        private void AppBarButton_Click_4(object sender, RoutedEventArgs e)
        {
            Windows.UI.Text.ITextSelection selectedText = NoteContent.Document.Selection;
            if (selectedText != null)
            {
                Windows.UI.Text.ITextCharacterFormat charFormatting = selectedText.CharacterFormat;
                charFormatting.Italic = Windows.UI.Text.FormatEffect.Toggle;
                selectedText.CharacterFormat = charFormatting;
            }
        }

        private void AppBarButton_Click_5(object sender, RoutedEventArgs e)
        {
            Windows.UI.Text.ITextSelection selectedText = NoteContent.Document.Selection;
            if (selectedText != null )
            {
                Windows.UI.Text.ITextCharacterFormat charFormatting = selectedText.CharacterFormat;
                charFormatting.Bold = Windows.UI.Text.FormatEffect.Toggle;
                selectedText.CharacterFormat = charFormatting;
            }
        }

        private void AboutButton_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(AboutPageView));
        }
    }
}
