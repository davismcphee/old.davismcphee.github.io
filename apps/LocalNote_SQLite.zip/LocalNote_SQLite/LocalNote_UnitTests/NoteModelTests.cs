﻿using System;
using Microsoft.VisualStudio.TestPlatform.UnitTestFramework;
using LocalNote.Models;

namespace LocalNote_UnitTests
{
    [TestClass]
    public class NoteModelTests
    {
        [TestMethod]
		public void CreateANoteWithoutAValidFile()
        {
			Assert.Fail();
        }
    }
}
