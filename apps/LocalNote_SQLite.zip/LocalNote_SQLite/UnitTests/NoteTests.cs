﻿using System;
using Microsoft.VisualStudio.TestPlatform.UnitTestFramework;
using LocalNote;
using LocalNote.Models;
using LocalNote.ViewModels;
using Windows.Storage;

namespace UnitTests
{
    [TestClass]
    public class NoteTests
    {
        public Note ProcessItem { get; private set; }

        [TestMethod]
        public void SuccessfullyCreateMainPageViewModel()
        {
			MainPageViewModel mainPageViewModel = new MainPageViewModel();
			Assert.AreNotEqual(mainPageViewModel, null, "Main Page View Model is null.");
        }

		[TestMethod]
		public void SuccessfullyCreateNewNote()
		{
			int noteId = 0;
			int expectedNoteId = 0;
			string noteTitle = "Title";
			string expectedNoteTitle = "Title";
            string noteContent = "Content";
            string expectedNoteContent = "Content";
            //note no longer takes a file
            //no longer uses constructor to add properties
            Note note = new Note()
            {
                ID = noteId,
                Title = noteTitle,
                Content = noteContent
            };
			Assert.AreEqual(expectedNoteId, note.ID, "IDs are not equal.");
			Assert.AreEqual(expectedNoteTitle, note.Title, "Titles are not equal.");
			Assert.AreEqual(expectedNoteContent, note.Content, "Files are not equal.");
		}

		[TestMethod]
		public void SuccessfullyAddToNotesList()
		{
			MainPageViewModel mainPageViewModel = new MainPageViewModel();
            //No longer uses any files when adding to notes list
            Note note = new Note()
            {
                ID = 0,
                Title = "Title",
                Content = "Content"
            };
            mainPageViewModel.Notes.Add(note);
			Assert.IsTrue(mainPageViewModel.Notes.Count > 0, "Note did not get added.");
		}

		public void SuccessfullyAddThenRemoveFromNotesList()
		{
			MainPageViewModel mainPageViewModel = new MainPageViewModel();
            Note note = new Note()
            {
                ID = 0,
                Title = "Title",
                Content = "Content"
            };
            mainPageViewModel.Notes.Add(note);
			Assert.IsTrue(mainPageViewModel.Notes.Count > 0, "Note did not get added.");
			mainPageViewModel.Notes.Remove(note);
			Assert.IsTrue(mainPageViewModel.Notes.Count < 1, "Note did not get removed.");
		}

		[TestMethod]
		public void SuccessfullySetSelectedNote()
		{
			MainPageViewModel mainPageViewModel = new MainPageViewModel();
            Note note = new Note()
            {
                ID = 0,
                Title = "Title",
                Content = "Content"
            };
            mainPageViewModel.SelectedNote = note;
			Assert.AreEqual(note, mainPageViewModel.SelectedNote, "Selected note was not updated.");
		}

		[TestMethod]
		public void SuccessfullySetActiveContent()
		{
			string activeContent = "active content";
			string expectedActiveContent = "active content";
			MainPageViewModel mainPageViewModel = new MainPageViewModel();
			mainPageViewModel.ActiveContent = activeContent;
			Assert.AreEqual(expectedActiveContent, mainPageViewModel.ActiveContent, "Content was not updated");
		}

		[TestMethod]
		public void CheckThatICommandObjectsAreBeingCreated()
		{
			MainPageViewModel mainPageViewModel = new MainPageViewModel();
			Assert.AreNotEqual(null, mainPageViewModel.AboutCommand, "About command was null.");
			Assert.AreNotEqual(null, mainPageViewModel.AddNoteCommand, "Add note command was null.");
			Assert.AreNotEqual(null, mainPageViewModel.DeleteNoteCommand, "Delete note command was null.");
			Assert.AreNotEqual(null, mainPageViewModel.EditNoteCommand, "Edit note command was null.");
			Assert.AreNotEqual(null, mainPageViewModel.ExitCommand, "Exit command was null.");
			Assert.AreNotEqual(null, mainPageViewModel.SaveNoteCommand, "Save note command was null.");
		}

		[TestMethod]
		public void NoteContentIsNotReadOnlyOnStart()
		{
			MainPageViewModel mainPageViewModel = new MainPageViewModel();
			Assert.AreEqual(false, mainPageViewModel.NoteContentIsReadOnly, "Note content is read only.");
		}

		[TestMethod]
		public void IsEnabledPropertiesAreProperlySetAtStart()
		{
			MainPageViewModel mainPageViewModel = new MainPageViewModel();
			bool expectedSearchBoxIsEnabled = true;
			bool expectedEditButtonIsEnabled = true;
			bool expectedAddButtonIsEnabled = true;
			bool expectedDeleteButtonIsEnabled = true;
			bool expectedSaveButtonIsEnabled = true;
			Assert.AreEqual(expectedSearchBoxIsEnabled, mainPageViewModel.SearchBoxIsEnabled, "Search box was not enabled.");
			Assert.AreEqual(expectedEditButtonIsEnabled, mainPageViewModel.SearchBoxIsEnabled, "Edit button was not enabled.");
			Assert.AreEqual(expectedAddButtonIsEnabled, mainPageViewModel.SearchBoxIsEnabled, "Add button was not enabled.");
			Assert.AreEqual(expectedDeleteButtonIsEnabled, mainPageViewModel.SearchBoxIsEnabled, "Delete button was not enabled.");
			Assert.AreEqual(expectedSaveButtonIsEnabled, mainPageViewModel.SearchBoxIsEnabled, "Save button was not enabled.");
		}

		[TestMethod]
		public void SuccessfullySetIsEnabledProperties()
		{
			MainPageViewModel mainPageViewModel = new MainPageViewModel();
			bool expectedSearchBoxIsEnabled = true;
			bool expectedEditButtonIsEnabled = true;
			bool expectedAddButtonIsEnabled = true;
			bool expectedDeleteButtonIsEnabled = true;
			bool expectedSaveButtonIsEnabled = true;
			bool searchBoxIsEnabled = true;
			bool editButtonIsEnabled = true;
			bool addButtonIsEnabled = true;
			bool deleteButtonIsEnabled = true;
			bool saveButtonIsEnabled = true;
			mainPageViewModel.SearchBoxIsEnabled = searchBoxIsEnabled;
			mainPageViewModel.EditButtonIsEnabled = editButtonIsEnabled;
			mainPageViewModel.AddButtonIsEnabled = addButtonIsEnabled;
			mainPageViewModel.DeleteButtonIsEnabled = deleteButtonIsEnabled;
			mainPageViewModel.SaveButtonIsEnabled = saveButtonIsEnabled;
			Assert.AreEqual(expectedSearchBoxIsEnabled, mainPageViewModel.SearchBoxIsEnabled, "Search box was not set.");
			Assert.AreEqual(expectedEditButtonIsEnabled, mainPageViewModel.SearchBoxIsEnabled, "Edit button was not set.");
			Assert.AreEqual(expectedAddButtonIsEnabled, mainPageViewModel.SearchBoxIsEnabled, "Add button was not set.");
			Assert.AreEqual(expectedDeleteButtonIsEnabled, mainPageViewModel.SearchBoxIsEnabled, "Delete button was not set.");
			Assert.AreEqual(expectedSaveButtonIsEnabled, mainPageViewModel.SearchBoxIsEnabled, "Save button was not set.");
		}

        //New Unit Tests

        [TestMethod]
        public void SuccessfullyCreateANoteAndWriteToDatabase()
        {
            MainPageViewModel mainPageViewModel = new MainPageViewModel();
            string noteTitle = "Title";
            string noteContent = "Content";
            mainPageViewModel.CreateNewNote(noteTitle, noteContent);
            Assert.AreEqual(noteTitle, mainPageViewModel.Notes[(mainPageViewModel.Notes.IndexOf(ProcessItem)) + 1].Title, "Note was not written to database.");
        }

        [TestMethod]
        public void SuccessfullyCreateANoteAndDeleteIt()
        {
            MainPageViewModel mainPageViewModel = new MainPageViewModel();
            string noteTitle = "Title";
            string noteContent = "Content";
            mainPageViewModel.CreateNewNote(noteTitle, noteContent);
            Note note = mainPageViewModel.Notes[(mainPageViewModel.Notes.IndexOf(ProcessItem)) + 1];
            mainPageViewModel.DeleteNote(note);
            Assert.IsTrue(!mainPageViewModel.Notes.Contains(note), "Note did not get deleted");
        }

        [TestMethod]
        public void SuccessfullyCreateANoteAndModifyIt()
        {
            MainPageViewModel mainPageViewModel = new MainPageViewModel();
            string noteTitle = "Title";
            string noteContentModification = "ContentEDIT";
            string expectedNoteContentModification = "ContentEDIT";
            mainPageViewModel.CreateNewNote(noteTitle, "NULL");
            Note note = mainPageViewModel.Notes[(mainPageViewModel.Notes.IndexOf(ProcessItem)) + 1];
            mainPageViewModel.WriteToNote(note, noteContentModification);
            Assert.AreEqual(expectedNoteContentModification, note.Content, "Note did not get updated");
        }

    }
}
