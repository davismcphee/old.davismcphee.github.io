import os, sys, re, random

def test_input(regex, string):
    valid_input = False
    while not valid_input:
        input_string = input(string)
        if re.match(regex, input_string):
            valid_input = True;
        else:
            print("Invalid input. Try again.")
    return input_string

def main():
    file_name = test_input(r"[A-Za-z0-9/\-_\\ ]+", "Please enter a file name: ") + ".txt"
    list_length = test_input(r"[0-9]+", "Please enter a list length: ")
    list_min = test_input(r"-?[0-9]+", "Please enter a minimum list value: ")
    valid_range = False
    while not valid_range:
        list_max = test_input(r"-?[0-9]+", "Please enter a maximum list value: ")
        if int(list_max) > int(list_min):
            valid_range = True
        else:
            print("Range is not valid. Try Again.")
    delimiter = input("Please enter a delimiter to be used: ")
    number_list = []
    file = open(file_name, "a+")
    for i in range(int(list_length)):
        if i == int(list_length) - 1:
            file.write(str(random.randrange(int(list_min), int(list_max))))
        else:
            file.write(str(random.randrange(int(list_min), int(list_max))) + delimiter)
    file.close()

if __name__ == "__main__":
    main()