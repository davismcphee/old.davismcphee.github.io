﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileDuplicator
{
    class Program
    {
        static void Main(string[] args)
        {
            string path;
            int num;

            if (File.Exists(args[0]))
            {
                path = args[0];
            }
            else
            {
                Console.WriteLine("Error: Invalid path or insufficient privileges");
                return;
            }

            if (!int.TryParse(args[1], out num))
            {
                Console.WriteLine("Error: Second argument was not an integer");
                return;
            }

            string content = File.ReadAllText(path);

            for (int i = 0; i < num; i++)
            {
                File.WriteAllText(
                    path.Substring(0, path.LastIndexOf('.')) + "_" + i
                    + path.Substring(path.LastIndexOf('.')), 
                    content);
            }

        }
    }
}
