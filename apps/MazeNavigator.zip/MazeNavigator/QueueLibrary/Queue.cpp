#include "Queue.h"

Queue::~Queue() {
	empty();
}

void Queue::add(Node * node) {
	if (first == 0)
		first = node;
	else
		last->setNext(node);
	last = node;
}

Node * Queue::peek() {
	return first;
}

void Queue::serve() {
	Node* node = first;
	if (first != 0)
		first = first->getNext();
	else
		last = 0;
}

bool Queue::isEmpty() {
	return first == 0 && last == 0;
}

void Queue::empty() {
	while (first != 0) {
		serve();
	}
}
