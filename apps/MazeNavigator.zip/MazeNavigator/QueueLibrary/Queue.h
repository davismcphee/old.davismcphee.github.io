#pragma once
#ifndef QUEUE_H
#define QUEUE_H
#include "Node.h"
class __declspec(dllexport) Queue {
private:
	Node * first;
	Node * last;
public:
	Queue() : first(0), last(0) {}
	~Queue();
	void add(Node * node);
	Node * peek();
	void serve();
	bool isEmpty();
	void empty();
};
#endif // !QUEUE_H
