#pragma once
#ifndef NODE_H
#define NODE_H
class __declspec(dllexport) Node {
public:
	enum __declspec(dllexport) NodeType {
		start,
		open,
		blocked,
		checked,
		end
	};
	struct __declspec(dllexport) Coordinates {
		Coordinates() {}
		Coordinates(int x, int y) : x(x), y(y) {}
		int x;
		int y;
	};
	NodeType getNodeType() { return nodeType; }
	void setNodeType(NodeType nodeType) { this->nodeType = nodeType; }
	Coordinates getCoordinates() { return coordinates; }
	void setCoordinates(Coordinates coordinates) { this->coordinates = coordinates; }
	Node * getParent() { return parent; }
	void setParent(Node * parent) { this->parent = parent; }
	Node * getNext() { return next; }
	void setNext(Node * next) { this->next = next; }
	Node * getPrevious() { return previous; }
	void setPrevious(Node * previous) { this->previous = previous; }
private:
	NodeType nodeType;
	Coordinates coordinates;
	Node * parent = 0;
	Node * next = 0;
	Node * previous = 0;
};
#endif // !NODE_H