#pragma once
#include "../QueueLibrary/Queue.h"
#include "../QueueLibrary/Node.h"
#include <fstream>
#include <iostream>
#include <Windows.h>
class MazeReader {
public:
	~MazeReader();
	void clear();
	bool open(char * mazeFile);
	bool solveMaze(char * outputFile);
	Node * findEndNode();
private:
	const int START_X = 0;
	const int START_Y = 1;
	const int END_X = -1;
	const int END_Y = -2;
	const char OPEN_SPACE = ' ';
	const Node::Coordinates north = Node::Coordinates(-1, 0);
	const Node::Coordinates east = Node::Coordinates(0, 1);
	const Node::Coordinates south = Node::Coordinates(1, 0);
	const Node::Coordinates west = Node::Coordinates(0, -1);
	char ** charMaze;
	Node *** nodeMaze;
	int mazeWidth = 1;
	int mazeHeight = 1;
	Queue queue;
	void addToCharMaze(char charToAppend, int currentX);
	void deleteNodeMaze();
	void createNodeMaze();
	Node * checkNeighbour(Node * node, Node::Coordinates neighbourCoordinates);
	Node * checkNeighbours(Node * node);
};