#include "MazeReader.h"
#include <iostream>
#include <conio.h>

int main() {

	MazeReader mazeReader;
	mazeReader.open("maze.txt");
	mazeReader.solveMaze("maze_solution.txt");
	mazeReader.clear();
	mazeReader.open("maze2.txt");
	mazeReader.solveMaze("maze2_solution.txt");
	mazeReader.clear();
	mazeReader.open("maze3.txt");
	mazeReader.solveMaze("maze3_solution.txt");
	mazeReader.clear();
	mazeReader.open("maze4.txt");
	mazeReader.solveMaze("maze4_solution.txt");
	mazeReader.clear();
	mazeReader.open("mazex.txt");
	mazeReader.solveMaze("mazex_solution.txt");
	mazeReader.clear();
	mazeReader.open("supermaze.txt");
	mazeReader.solveMaze("supermaze_solution.txt");

	_getch();	return 0;
}