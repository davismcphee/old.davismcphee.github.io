#include "MazeReader.h"

MazeReader::~MazeReader() {
	clear();
}

//clear and reset all of the current settings
void MazeReader::clear() {
	if (charMaze != 0) {
		for (int i = 0; i < mazeHeight; i++)
			delete[] charMaze[i];
		delete[] charMaze;
	}
	queue.empty();
	if (nodeMaze != 0)
		deleteNodeMaze();
	mazeWidth = 1;
	mazeHeight = 1;
	charMaze = 0;
	nodeMaze = 0;
}

//check for line ending types in document
char detectLineEnding(std::ifstream & inStream) {
	char currentChar;
	while (inStream.get(currentChar) && currentChar != '\n' && currentChar != '\r' && currentChar != '\r\n');
	inStream.clear();
	inStream.seekg(0, std::ios::beg);
	return currentChar;
}

//add a new char to the char maze
void MazeReader::addToCharMaze(char charToAppend, int currentX) {
	char ** oldCharMaze = charMaze;
	//make a new maze of the current maze height
	charMaze = new char*[mazeHeight];
	for (int i = 0; i < mazeHeight; i++) {
		int currentWidth = mazeWidth;
		//if this is the last row, make the row width only the width required
		if (i == mazeHeight - 1)
			currentWidth = currentX + 1;
		charMaze[i] = new char[currentWidth];
		for (int j = 0; j < currentWidth; j++) {
			//if this is the last column in the last row, add the new  char
			if (i == mazeHeight - 1 && j == currentWidth - 1)
				charMaze[i][j] = charToAppend;
			//copy the old char
			else
				charMaze[i][j] = oldCharMaze[i][j];
		}
		//as long as there is a row to delete, do it
		if (currentWidth - 1 != 0)
			delete[] oldCharMaze[i];
	}
	delete[] oldCharMaze;
}

//delete everything in node maze
void MazeReader::deleteNodeMaze() {
	if (nodeMaze != 0) {
		for (int i = 0; i < mazeHeight; i++) {
			for (int j = 0; j < mazeWidth; j++)
				delete nodeMaze[i][j];
			delete[] nodeMaze[i];
		}
		delete[] nodeMaze;
	}
}

void MazeReader::createNodeMaze() {
	nodeMaze = new Node**[mazeHeight];
	for (int i = 0; i < mazeHeight; i++) {
		nodeMaze[i] = new Node*[mazeWidth];
		for (int j = 0; j < mazeWidth; j++) {
			//make the node, put it in maze and set coordinates
			Node * node = new Node();
			nodeMaze[i][j] = node;
			node->setCoordinates(Node::Coordinates(j, i));
			//check node type and set accordingly
			if (i == START_Y && j == START_X && charMaze[i][j] == OPEN_SPACE)
				node->setNodeType(Node::NodeType::start);
			else if (i == mazeHeight + END_Y && j == mazeWidth + END_X && charMaze[i][j] == OPEN_SPACE)
				node->setNodeType(Node::NodeType::end);
			else if (charMaze[i][j] == OPEN_SPACE)
				node->setNodeType(Node::NodeType::open);
			else
				node->setNodeType(Node::NodeType::blocked);
		}
	}
}

//check neighbour node in provided direction, return the end node if found
Node * MazeReader::checkNeighbour(Node * node, Node::Coordinates neighbourCoordinates) {
	int neighbourY = node->getCoordinates().y + neighbourCoordinates.y;
	int neighbourX = node->getCoordinates().x + neighbourCoordinates.x;
	Node * nextNode = nodeMaze[neighbourY][neighbourX];
	//if neighbour node is within maze range and is not blocked or already checked
	if (neighbourY >= 0 &&
		neighbourY < mazeHeight &&
		neighbourX >= 0 &&
		neighbourX < mazeWidth &&
		nextNode != 0 &&
		nextNode->getNodeType() != Node::NodeType::blocked &&
		nextNode->getNodeType() != Node::NodeType::checked) {
		//set the next node's parent to the node that found it
		nextNode->setParent(node);
		//if open node, add to que
		if (nextNode->getNodeType() == Node::NodeType::open) {
			queue.add(nextNode);
		}
		//if end node, return it
		else if (nextNode->getNodeType() == Node::NodeType::end)
			return nextNode;
	}
	return 0;
}

//check each neighbour and return end node if found, or null
Node * MazeReader::checkNeighbours(Node * node) {
	Node * returnNode = 0;
	returnNode = checkNeighbour(node, north);
	if (returnNode != 0 && returnNode->getNodeType() == Node::NodeType::end)
		return returnNode;
	returnNode = checkNeighbour(node, east);
	if (returnNode != 0 && returnNode->getNodeType() == Node::NodeType::end)
		return returnNode;
	returnNode = checkNeighbour(node, south);
	if (returnNode != 0 && returnNode->getNodeType() == Node::NodeType::end)
		return returnNode;
	returnNode = checkNeighbour(node, west);
	return returnNode;
}

//find the end node of the maze and return it
Node * MazeReader::findEndNode() {
	Node * endNode = 0;
	while (!queue.isEmpty()) {
		Node * node = queue.peek();
		if (node != 0) {
			endNode = checkNeighbours(node);
			//if end node found, break the loop
			if (endNode != 0 && endNode->getNodeType() == Node::NodeType::end)
				break;
			node->setNodeType(Node::NodeType::checked);
		}
		queue.serve();
	}
	return endNode;
}

//open the maze file
bool MazeReader::open(char * mazeFile) {
	std::ifstream inStream(mazeFile);
	bool isOpen;
	isOpen = inStream.is_open();
	if (isOpen) {
		//get the line ending type
		char lineEnding = detectLineEnding(inStream);
		char currentChar;
		int currentX = 0;
		while (inStream.get(currentChar)) {
			//if this char is the end of line, add a new row and reset the current x
			if (currentChar == lineEnding) {
				mazeHeight++;
				mazeWidth = currentX;
				currentX = 0;
			}
			//else, add the current char to the char maze
			else {
				addToCharMaze(currentChar, currentX);
				currentX++;
			}

		}
		//create the node maze and add the first node to the queue
		createNodeMaze();
		queue.add(nodeMaze[START_Y][START_X]);
	}
	return isOpen;
}

//solve the maze and write to output file
bool MazeReader::solveMaze(char * outputFile) {
	std::ofstream outStream(outputFile);
	bool good = false;
	if (outStream.is_open()) {
		//get the end node
		Node * node = findEndNode();
		//retrace the path and replace coordinates in char maze with 'X'
		while (node != 0) {
			int nodeX = node->getCoordinates().x;
			int nodeY = node->getCoordinates().y;
			charMaze[nodeY][nodeX] = 'X';
			node = node->getParent();
		}
		//print the maze to the console and write it to the output file
		HANDLE colourHandler = GetStdHandle(STD_OUTPUT_HANDLE);
		for (int i = 0; i < mazeHeight; i++) {
			for (int j = 0; j < mazeWidth; j++) {
				if (charMaze[i][j] == 'X')
					SetConsoleTextAttribute(colourHandler, 10);
				else
					SetConsoleTextAttribute(colourHandler, 12);
				std::cout << charMaze[i][j];
				outStream << charMaze[i][j];
			}
			std::cout << '\n';
			outStream << '\n';
		}
		good = true;
	}
	return good;
}

