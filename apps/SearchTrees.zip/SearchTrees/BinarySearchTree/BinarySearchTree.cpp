#include "BinarySearchTree.h"

BinarySearchTree::Node * BinarySearchTree::insert(Node * root, const char * content)
{
	//if the last node passed to insert was null, make a node with this content
	if (root == 0) {
		root = new Node(content, 0, 0);
	}
	else {
		//copare this node's content to the passed content
		if (strcmp(content, root->content) < 0) {
			//if this content is first alphabetically, call insert on the left of this node
			root->left = insert(root->left, content);
		}
		else {
			//else, call inset on right
			root->right = insert(root->right, content);
		}
		//check the balance and adjust this node accordingly
		root = balance(root);
	}
	return root;
}

bool BinarySearchTree::search(Node * root, const char * content)
{
	bool found;
	//if this node is null, node was not found
	if (root == 0) {
		found = false;
	}
	//if this node's content is lower alphabetically, search to the left of it
	else if (strcmp(content, root->content) < 0) {
		found = search(root->left, content);
	}
	//if higher, search to the right
	else if (strcmp(content, root->content) > 0) {
		found = search(root->right, content);
	}
	//the node's content was a match!
	else {
		found = true;
	}
	return found;
}

void BinarySearchTree::remove(Node * root)
{
	//make sure all children node's get deleted before their parents
	if (root->left) {
		remove(root->left);
	}
	if (root->right) {
		remove(root->right);
	}
	delete[] root->content;
	delete root;
}

int BinarySearchTree::calcBalance(Node * root) {
	//checks the difference in height of children subtrees
	return calcHeight(root->left) - calcHeight(root->right);
}

int BinarySearchTree::calcHeight(Node * root) {
	int height = 0;
	//as long as this node isn't null
	if (root) {
		//calculate this node's children's height
		int leftHeight = calcHeight(root->left);
		int rightHeight = calcHeight(root->right);
		//this height is the larger of the two plus one
		height = (leftHeight > rightHeight ? leftHeight : rightHeight) + 1;
	}
	return height;
}

BinarySearchTree::Node * BinarySearchTree::balance(Node * root)
{
	//get the balance of this subtree
	int balance = calcBalance(root);
	//unbalanced on left side
	if (balance > 1) {
		//extra node on left side
		if (calcBalance(root->left) > 0) {
			root = rotateLeft(root);
		}
		//extra node on right side
		else {
			root = rotateLeftRight(root);
		}
	}
	//unbalanced on right side
	else if (balance < -1) {
		//extra node on left side
		if (calcBalance(root->right) > 0) {
			root = rotateRightLeft(root);
		}
		//extra node on right side
		else {
			root = rotateRight(root);
		}
	}
	return root;
}

BinarySearchTree::Node * BinarySearchTree::rotateLeft(Node * root)
{
	//create a temporary node of the parent node's left child
	Node * temporaryNode = root->left;
	//set the parent node's new left child to them temporary node's right child
	root->left = temporaryNode->right;
	//make the original parent the temporary node's right child
	temporaryNode->right = root;
	return temporaryNode;
}

BinarySearchTree::Node * BinarySearchTree::rotateRight(Node * root)
{
	//same as rotate left but opposite
	Node * temporaryNode = root->right;
	root->right = temporaryNode->left;
	temporaryNode->left = root;
	return temporaryNode;
}

BinarySearchTree::Node * BinarySearchTree::rotateLeftRight(Node * root)
{
	//rotate right around the parent's left child
	root->left = rotateRight(root->left);
	//rotate left around this node
	return rotateLeft(root);
}

BinarySearchTree::Node * BinarySearchTree::rotateRightLeft(Node * root)
{
	//same as left right but opposite
	root->right = rotateLeft(root->right);
	return rotateRight(root);
}

void BinarySearchTree::insert(const char * content)
{
	//insert the node
	root = insert(root, content);
}

bool BinarySearchTree::search(const char * content)
{
	//do a search
	return search(root, content);
}

BinarySearchTree::~BinarySearchTree()
{
	//remove all of the nodes
	remove(root);
}
