#pragma once
#include <string.h>

class BinarySearchTree
{
public:
	struct Node {
		Node(const char * content, Node * left, Node * right) :
			content(content), left(left), right(right) {}
		Node * left;
		Node * right;
		const char * content;
	};
	void insert(const char * content);
	bool search(const char * content);
	Node * getRoot() { return root; }
	~BinarySearchTree();
private:
	Node * root = 0;
	Node * insert(Node * root, const char * content);
	bool search(Node * root, const char * content);
	void remove(Node * root);
	int calcBalance(Node * root);
	int calcHeight(Node * root);
	Node * balance(Node * root);
	Node * rotateLeft(Node * root);
	Node * rotateRight(Node * root);
	Node * rotateLeftRight(Node * root);
	Node * rotateRightLeft(Node * root);
};

