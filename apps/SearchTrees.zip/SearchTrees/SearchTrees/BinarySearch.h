#pragma once
#include "Search.h"
class BinarySearch :
	public Search
{
public:
	virtual int search(int * array, int arrayLength, int target);
	BinarySearch();
	~BinarySearch();
};

