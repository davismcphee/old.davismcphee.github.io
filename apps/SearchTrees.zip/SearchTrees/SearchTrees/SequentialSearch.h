#pragma once
#include "Search.h"
class SequentialSearch :
	public Search
{
public:
	virtual int search(int * array, int arrayLength, int target);
	SequentialSearch();
	~SequentialSearch();
};

