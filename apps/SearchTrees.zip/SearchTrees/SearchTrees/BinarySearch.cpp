#include "BinarySearch.h"



int BinarySearch::search(int * array, int arrayLength, int target)
{
	int bottom = 0, 
		top = arrayLength, 
		mid;
	bool done = false;
	//while the search is not complete
	while (!done) {
		//find the middle of the current array segment
		mid = bottom + (top - bottom) / 2;
		//check whether the number we are looking for is bigger, smaller or equal than the middle
		if (mid < target) {
			bottom = mid + 1;
		}
		else if (mid > target) {
			top = mid;
		}
		else {
			done = true;
		}
	}
	return mid;
}

BinarySearch::BinarySearch()
{
}


BinarySearch::~BinarySearch()
{
}
