#pragma once
class Search
{
public:
	virtual int search(int * array, int arrayLength, int target) = 0;
	virtual ~Search(){}
};

