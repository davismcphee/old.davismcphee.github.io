#include "SequentialSearch.h"



int SequentialSearch::search(int * array, int arrayLength, int target)
{
	//for each item, check equality
	for (int i = 0; i < arrayLength; i++)
		if (target == array[i]) return i;
	return -1;
}

SequentialSearch::SequentialSearch()
{
}


SequentialSearch::~SequentialSearch()
{
}
