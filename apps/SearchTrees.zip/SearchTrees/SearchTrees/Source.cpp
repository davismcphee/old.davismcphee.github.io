#include "SequentialSearch.h"
#include "BinarySearch.h"
#include "../BinarySearchTree/BinarySearchTree.h"
#include <chrono>
#include <iostream>
#include <conio.h>
#include <fstream>
#include <string>
#include <algorithm>
#include <locale>
#include <iomanip> 

void printBinarySearchTree(BinarySearchTree::Node * root) {
	if (root) {
		//print this node's subtrees first
		printBinarySearchTree(root->left);
		printBinarySearchTree(root->right);
		//print this node's content and it's children's conten if it has any
		std::cout << "------------------------------\n";
		std::cout << "Content: \"" + std::string(root->content) + "\"";
		if (root->left) {
			std::cout << ",\nLeft Child Content: \"" + std::string(root->left->content) + "\"";
		}
		if (root->right) {
			std::cout << ",\nRight Child Content: \"" + std::string(root->right->content) + "\"";
		}	
		std::cout << "\n";
	}
}

//http://www.sanfoundry.com/cpp-program-implement-avl-trees/
void display(BinarySearchTree * tree, BinarySearchTree::Node *ptr, int level)
{
	int i;
	if (ptr)
	{
		display(tree, ptr->right, level + 1);
		printf("\n");
		if (ptr == tree->getRoot())
			std::cout << "Root -> ";
		for (i = 0; i < level && ptr != tree->getRoot(); i++)
			std::cout << "        ";
		std::cout << ptr->content;
		display(tree, ptr->left, level + 1);
	}
}

int main() {

	/* SEARCH ALGORITHMS */

	//make and array numbered 0-999
	int array[1000];
	for (int i = 0; i < 1000; i++) {
		array[i] = i;
	}
	SequentialSearch sequentialSearch;
	BinarySearch binarySearch;
	//time the search for each number in the list for both sequential and binary searches
	//print the results to the console
	std::cout << "Beginning sequential search for 1000 iterations...\n";
	auto startTime = std::chrono::high_resolution_clock::now();
	for (int i = 0; i < 1000; i++) {
		sequentialSearch.search(array, 1000, i);
	}
	auto endTime = std::chrono::high_resolution_clock::now();
	auto totalTime = std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();
	std::cout << "Sequential search time: " << totalTime << " nanoseconds\n";
	std::cout << "Beginning binary search for 1000 iterations...\n";
	startTime = std::chrono::high_resolution_clock::now();
	for (int i = 0; i < 1000; i++) {
		binarySearch.search(array, 1000, i);
	}
	endTime = std::chrono::high_resolution_clock::now();
	totalTime = std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();
	std::cout << "Binary search time: " << totalTime << " nanoseconds\n";

	_getch();

	/* BINARY SEARCH TREE */

	BinarySearchTree binarySearchTree;
	std::ifstream inputStream;
	inputStream.open("dictionary.txt", std::ios::in);
	std::string currentWord;
	char * currentWordChar;
	//read the dictionary and insert each word into binary search tree
	if (inputStream) {
		while (inputStream >> currentWord) {
			int length = currentWord.length();
			currentWordChar = new char[length + 1];
			#pragma warning( push )
			#pragma warning( disable : 4996)
			sprintf(currentWordChar, "%s", currentWord.c_str());
			#pragma warning ( pop )
			binarySearchTree.insert(currentWordChar);
		}
	}
	//printBinarySearchTree(binarySearchTree.getRoot());
	display(&binarySearchTree, binarySearchTree.getRoot(), 0);
	std::cout << "\n";
	//std::cout << "------------------------------\n";

	_getch();

	inputStream.close();
	inputStream.open("mispelled.txt", std::ios::in);
	//read each word in the document, strip non-numeric characters and convert to lower case
	//then search for each word in the dictionary search tree
	if (inputStream) {
		std::cout << "Mispellings:\n";
		while (inputStream >> currentWord)
		{
			//http://stackoverflow.com/questions/28491954/remove-non-alphabet-characters-from-string-c
			currentWord.erase(std::remove_if(currentWord.begin(), currentWord.end(), [](char c) { return !isalpha(c); }), currentWord.end());
			//http://stackoverflow.com/questions/313970/how-to-convert-stdstring-to-lower-case
			std::transform(currentWord.begin(), currentWord.end(), currentWord.begin(), ::tolower);
			//print to console if the word is mispelled
			if (currentWord.length() > 0 && !binarySearchTree.search(currentWord.c_str())) {
				std::cout << "- " << currentWord << "\n";
			}
		}
	}

	_getch();

	return 0;
}